# Madhura Kitchen V6 — GitHub Pages Editable Website

## Publish on GitHub Pages
1. Create a GitHub repository.
2. Upload the entire contents of this folder.
3. Keep `index.html` in the repository root.
4. Go to **Settings → Pages** and select **Deploy from branch**, then choose `main` and `/ (root)`.
5. Open the generated GitHub Pages URL.

## Edit without changing HTML
Open **Owner Login → Settings** or the relevant dashboard section.
- Edit dish name, price, category, description and availability.
- Upload a food image or paste an image URL.
- Edit logo, owner photo, owner name, address, phone, WhatsApp, email, hours and Marathi tagline.
- Changes are saved in the browser's local storage.

## Publish your edits to the public GitHub website
GitHub Pages is static and a browser cannot safely write your edits directly into your GitHub repository.
1. Login as Owner.
2. Open **Settings → GitHub Publishing**.
3. Click **Download GitHub default-state.json**.
4. In GitHub, replace `data/default-state.json` with the downloaded file.
5. Commit the change. GitHub Pages will redeploy automatically.

The exported state contains your menu, business profile and operational data. For a public production site, do **not** put customer orders, passwords, payment information or other sensitive records into a public GitHub repository. Move those records to a secure backend/database.

## Important security note
The demo Owner Login is front-end only. It is not secure authentication. Before accepting real orders/payments or storing personal data, use a server-side authentication system, HTTPS, database access controls, hashed passwords, backups, audit logs and a secure image storage service.
